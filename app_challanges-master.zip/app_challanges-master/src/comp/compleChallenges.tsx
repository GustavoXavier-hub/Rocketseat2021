import style from '../style/components/compleChallenges.module.css'

export function CompleteChangelles(){
    return(
        <div className={style.challangesContainer}>
            <span>Desafios Completos</span>
            <span>5</span>
        </div>
    )
}